

public final class Constants {

    public static final String LOG_TAG = "FileExplorer";

    private Constants() {
    }
}
