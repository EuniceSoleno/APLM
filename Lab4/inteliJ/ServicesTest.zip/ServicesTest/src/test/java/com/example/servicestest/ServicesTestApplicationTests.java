package com.example.servicestest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServicesTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
